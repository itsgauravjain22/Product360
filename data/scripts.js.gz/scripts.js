var steps_one_revolution = 360;
var direction = 'cw';
var no_of_steps = 0;
var photo_count = 0;
var photo_step_count = 1;
var progress = 0;
$(document).ready(function () {
    if (localStorage['lock'] == 'true') {
        $('#lock').html('Unlock').attr('class', 'btn btn-warning');
        swal({
            title: 'UI Locked!',
            text: 'Press Unlock Button to enable UI interaction.',
            type: 'error'
        })
    } else if (localStorage['lock'] == 'false' || localStorage['lock'] == undefined) {
        $('#lock').html('Lock').attr('class', 'btn btn-warning');
    }

    $('input[type="number"]').number({
        'containerClass': 'number-style',
        'minus': 'number-minus',
        'plus': 'number-plus',
        'containerTag': 'div',
        'btnTag': 'span'
    });

    //Events driven methods
    $('input[name="no_of_steps"]').on('change', function () {
        var thisval = parseInt(this.value);
        no_of_steps = Math.abs(thisval) % steps_one_revolution;
        $(this).val(no_of_steps);
        if (Math.abs(thisval) > steps_one_revolution) {
            $(this).notify(
                "Only values beetwen 0 and " + steps_one_revolution + " are allowed.\nValues greater than " + steps_one_revolution + " will automatically adjust.", {
                    position: "top"
                }
            );
        }
    });

    $('input[name="direction"]').on('change', function () {
        if (this.value == 'clockwise') {
            direction = 'cw';
        } else if (this.value == 'anticlockwise') {
            direction = 'ccw'
        }

    });

    $('#btn_rotate').on('click', function () {
        if (localStorage['lock'] == 'true') {
            swal({
                title: 'UI Locked',
                text: 'Unlock the UI First',
                type: 'error'
            })
        } else {
            $.ajax({
                type: 'POST',
                url: "post/rotate",
                data: {
                    'steps': no_of_steps,
                    'direction': direction
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    swal({
                        title: 'Error',
                        text: 'Rotation process can\'t be completed\nStatus: ' + textStatus + ',\nError: ' + errorThrown,
                        type: 'error'
                    })
                }
            })
        }
    });
    $('input[name="photoCount"]').on('change', function () {
        var thisval = parseInt(this.value);
        if (thisval <= steps_one_revolution && thisval >= 1) {
            photo_count = this.value % steps_one_revolution;
        } else {
            photo_count = 0;
            $(this).val(photo_count);
            $(this).notify(
                "Only values beetwen 1 and " + steps_one_revolution + " are allowed.", {
                    position: "top"
                }
            );
        }
    });
    $('input[name="photoStepCount"]').on('change', function () {
        var thisval = parseInt(this.value);
        if (thisval <= steps_one_revolution && thisval >= 1) {
            photo_step_count = this.value % steps_one_revolution;
        } else {
            photo_step_count = 1;
            $(this).val(photo_step_count);
            $(this).notify(
                "Only values beetwen 1 and " + steps_one_revolution + " are allowed.", {
                    position: "top"
                }
            );
        }
    });
    $('#btn_count').on('click', function () {
        if (localStorage['lock'] == 'true') {
            swal({
                title: 'UI Locked',
                text: 'Unlock the UI First',
                type: 'error'
            })
        } else {
            swal({
                title: 'Photo Count',
                text: photo_count + ' photos will shoot for each ' + photo_step_count + ' rotation steps.'
            })
        }
    });
    $('#btn_shoot').on('click', function () {
        if (localStorage['lock'] == 'true') {
            swal({
                title: 'UI Locked',
                text: 'Unlock the UI First',
                type: 'error'
            })
        }
        else {
            $.ajax({
                type: 'POST',
                url: "post/rotateandshoot",
                data: {
                    'photoCount': photo_count,
                    'shootInterval': photo_step_count,
                    'direction': direction
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    swal({
                        title: 'Error',
                        text: 'Rotation and Shoot process can\'t be completed\nStatus: ' + textStatus + ',\nError: ' + errorThrown,
                        type: 'error'
                    })
                }
            })
        }
    });
    $('#status').on('click', function () {
        if (localStorage['lock'] == 'true') {
            swal({
                title: 'UI Locked',
                text: 'Unlock the UI First',
                type: 'error'
            })
        } else {
            $.ajax({
                type: 'POST',
                url: "post/status",
                dataType: 'json',
                success: function (data) {
                    swal({
                        title: 'Device Connected',
                        html: '<b>Message: </b><span>'+data.message+'</span>',
                        type: 'info'
                      })
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    swal({
                        title: 'Error',
                        text: 'Device Not Found\nStatus: ' + textStatus + ',\nError: ' + errorThrown,
                        type: 'error'
                    })
                }
            })
        }
    });
    $('#help').on('click', function () {
        $help = `<p style="text-align:left;"><b>Description:</b></p>
                <p style="text-align:left;">This free and open source program can be used to take 360 degree product photography virelessly. The program consists of two parts (the Positioning and the Rotating photography frame).</p>
                <p style="text-align:left;"><b>The positioning frame:</b></p>
                <p style="text-align:left;">
                Use this frame to rotate and position the object. It is useful to check whether the object is always in the field of view over the full turn. Set the No. of steps and press the Rotate button. The direction of the rotation can be set by the radio buttons.
            	Attention: the device will rotate only if the 360Product_firmware.ino file is flashed to the nodemcu.
                The file is available <a target="_blank" href="#">here</a>.</p>
                <p style="text-align:left;"><b>The rotating photography frame:</b></p>
                <ul>
                <li style="text-align:left;"><b>The Count button:</b><br />
                After setting the No. of photos and the No. of steps, the No. of all steps can be checked.</li>
                <li style="text-align:left;"><b>The Shoot button:</b><br />
                After setting both the No. of photos and the No. of steps, use this button to start taking photos. Before clicking this button, make sure the camera is set properly.</li>
            	<li style="text-align:left;"><b>Abort button:</b><br />
            	Use this button for aborting the running process.</li>
                </ul>
            	<p style="text-align:center;">For further information visit <a target="_blank" href=#>here</a>.</p>
                <p>Author: Gaurav Jain - Jan 2018.</p>
            	`;
        swal({
            title: 'Product360 v1.0 Help',
            type: 'info',
            width: '80%',
            allowOutsideClick: false,
            html: $help,
            focusConfirm: true,
            confirmButtonText: 'Ok!',
            onOpen: 'test'
        })
    });
    $('#abort').on('click', function () {
        if (localStorage['lock'] == 'false' || localStorage['lock'] == undefined) {
            swal({
                title: 'Do you want to abort?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, abort!',
                cancelButtonText: 'No, cancel!',
                confirmButtonClass: 'btn btn-success',
                cancelButtonClass: 'btn btn-danger',
                buttonsStyling: false,
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    $.ajax({
                        type: 'POST',
                        url: "post/abort",
                        dataType: 'json',
                        success: function (data) {
                            swal(
                                'Aborted!',
                                'Process has been aborted.',
                                'error'
                            )
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            swal({
                                title: 'Error',
                                text: 'Cannot abort the process\nStatus: ' + textStatus + ',\nError: ' + errorThrown,
                                type: 'error'
                            })
                        }
                    })
                }
            })
        } else if(localStorage['lock'] == 'true'){
            swal({
                title: 'UI Locked',
                text: 'Unlock the UI First',
                type: 'error'
            })
        }
    });
    $('#lock').on('click', function () {
        if (localStorage['lock'] == 'true') {
            swal({
                title: 'Do you want to unlock UI?',
                text: "Interaction with UI will be enabled!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, Unlock!',
                cancelButtonText: 'No, cancel!',
                confirmButtonClass: 'btn btn-success',
                cancelButtonClass: 'btn btn-danger',
                buttonsStyling: false,
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    localStorage['lock'] = 'false';
                    $('#lock').html('Lock').attr('class', 'btn btn-warning');
                    swal(
                        'UI Unlocked!',
                        'You can continue your work.',
                        'success'
                    )
                }
            })
        } else if (localStorage['lock'] == 'false' || localStorage['lock'] == undefined) {
            swal({
                title: 'Do you want to lock UI?',
                text: "Interaction with UI will be disabled until enabled again!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, Lock!',
                cancelButtonText: 'No, cancel!',
                confirmButtonClass: 'btn btn-success',
                cancelButtonClass: 'btn btn-danger',
                buttonsStyling: false,
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    localStorage['lock'] = 'true';
                    $('#lock').html('Unlock').attr('class', 'btn btn-warning');
                    swal(
                        'UI locked!',
                        'Press Unlock button to resume interaction.',
                        'success'
                    )
                }
            })
        }
    });
});